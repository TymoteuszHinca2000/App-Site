<!DOCTYPE html>
<html @php(language_attributes())>
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        @php(do_action('get_header'))
        @php(wp_head())

        @vite(['resources/css/app.css', 'resources/js/app.js'])
        @livewireStyles
    </head>

    <body @php(body_class('group/body'))>
        @php(wp_body_open())

        <div id="app" class="overflow-x-clip">
            <a class="sr-only focus:not-sr-only" href="#main">
                {{ __('Przejdź do treści', 'appandsite') }}
            </a>

            @include('sections.header')
            @include('partials.menu-mobile')

            <main id="main" class="main" tabindex="-1">
                @yield('content')
            </main>

            @include('sections.footer')
        </div>

        @php(do_action('get_footer'))
        @php(wp_footer())
        @livewireScripts
    </body>
</html>
